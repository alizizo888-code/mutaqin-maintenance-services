# مُتقن MUTQAN — منصة الصيانة

المستودع يضم أساس PHP + MySQL، وواجهات HTML التجريبية، ونسخة جزئية من تصدير React/Vite.

## آخر تحديث لمصدر React
تم رفع 16 ملفًا من المستوى الرئيسي إلى `react-export/src/`، و20 صفحة تشغيلية إلى `react-export/src/pages/`، و11 صفحة لواجهة العميل إلى `react-export/src/pages/client/`، واكتمل رفع 49 ملفًا إلى `react-export/src/lib/`.

**تصدير React غير مكتمل بعد:** تم رفع 11 صفحة للعميل واكتمل رفع 49 ملفًا إلى `react-export/src/lib/`.
- `react-export/src/components/` — تم العثور على 21 ملفًا مرفوعًا يدويًا، ونُسخت إلى المسار الصحيح داخل نسخة React
- `react-export/src/hooks/` — تم رفع 11 ملفًا ضمن الدفعة المستلمة

ملاحظة: ملفات `lib` ذات الأسماء التي تبدأ بشرطة سفلية وكذلك الملفات `ai.js` و`auth.js` و`db.js` و`maps.js` وغيرها من هذه الدفعات موثّقة داخلها كواجهات stub لمنصة Whacka؛ وهي لا تحتوي على تنفيذ خدمات المنصة الفعلية. لذلك يجب استبدالها أو تكييفها قبل تشغيل نسخة مستقلة.

بعض ملفات الإعدادات و`src` تعتمد على SDK خاص بمنصة Whacka، وتصدير README الأصلي يوضح أن خدمات المصادقة والبيانات والتخزين والذكاء الاصطناعي ليست ضمن التصدير وحده؛ لذلك لا يعتبر مجلد React الحالي بناءً مستقلًا قابلًا للتشغيل حتى اكتمال هذه التبعيات وتكييفها.

## تنزيل الحزمة الثنائية
- [تنزيل mutqan-php-clean-package.zip](https://github.com/alizizo888-code/mutaqin-maintenance-services/raw/refs/heads/main/mutqan-php-clean-package.zip)
- [سجل بناء الحزمة](https://github.com/alizizo888-code/mutaqin-maintenance-services/actions/workflows/build-package.yml)

ZIP الحالي يُبنى تلقائيًا من شجرة المستودع؛ بعد كل رفع إلى `main` يعاد بناؤه والتحقق منه.

## تشغيل نسخة PHP
1. استورد `database/schema.sql` في قاعدة MySQL جديدة.
2. انسخ `backend/config/config.local.php.example` إلى `backend/config/config.local.php`.
3. أدخل بيانات MySQL من Hostinger محليًا، ولا ترفع الأسرار إلى GitHub.
4. اختبر الموقع بعد إعداد الاتصال.
